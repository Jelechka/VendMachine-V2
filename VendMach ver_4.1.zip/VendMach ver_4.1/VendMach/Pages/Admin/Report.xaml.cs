﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using VendMach.Scripts;

namespace VendMach.Pages.Admin
{
    /// <summary>
    /// Логика взаимодействия для Report.xaml
    /// </summary>
    public partial class Report : Page
    {
        public Report()
        {
            InitializeComponent();

            List<ReportHelper> reportHelpers = new List<ReportHelper>();
            int i = 0;
            foreach (DrinksInMach dim in ConnectHelper.entObj.DrinksInMach)
            {
                int countStart = MainWindow.countInStart[i].Count;
                reportHelpers.Add(new ReportHelper
                {
                    Name = dim.Name,
                    Cost = dim.Cost,
                    CountActual = dim.Count,
                    CountStart = countStart,
                    Profit = (countStart - dim.Count) * dim.Cost
                });
                i++;
            }
            tbDate.Text = DateTime.Today.ToString("dd.MM.yyyy");
            dgReport.ItemsSource = reportHelpers;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }
    }
}
