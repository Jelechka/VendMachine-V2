﻿using System.Windows;
using System.Windows.Controls;
using VendMach.Scripts;

namespace VendMach.Pages.Admin
{
    /// <summary>
    /// Логика взаимодействия для MainAdmin.xaml
    /// </summary>
    public partial class MainAdmin : Page
    {
        public MainAdmin()
        {
            InitializeComponent();
        }

        private void btn_Back_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void btn_MoneyEdit_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new MoneyEdit());
        }

        private void btnViewDrinks_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new ViewDrinks());
        }

        private void btnReportView_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new Report());
        }
    }
}
