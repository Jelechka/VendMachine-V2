﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using VendMach.Pages.Admin;
using VendMach.Scripts;

namespace VendMach.Pages
{
    /// <summary>
    /// Логика взаимодействия для UserUI.xaml
    /// </summary>
    public partial class UserUI : Page
    {

        public UserUI()
        {
            InitializeComponent();
        }

        //Список напитков
        List<DrinksInMach> dim = ConnectHelper.entObj.DrinksInMach.Where(d => d.VendMachId == 1).ToList();
        List<CoinsInMach> cim = ConnectHelper.entObj.CoinsInMach.Where(c => c.VendMachId == 1).ToList();

        //монтеки 10 5 2 1
        int[] coins = { 0, 0, 0, 0 };

        //При загрузке приложения загружает с БД и выводит на экран картинки и данные по напиткам
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            dim = ConnectHelper.entObj.DrinksInMach.Where(d => d.VendMachId == 1).ToList();
            cim = ConnectHelper.entObj.CoinsInMach.Where(c => c.VendMachId == 1).ToList();
            spDrinks.Children.Clear();
            //Вывод (перебор) товаров на экран
            foreach (DrinksInMach drink in dim)
            {
                //создание картинки
                byte[] imageData = drink.Image;
                var image = new BitmapImage();
                using (var mem = new MemoryStream(imageData))
                {
                    mem.Position = 0;
                    image.BeginInit();
                    image.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
                    image.CacheOption = BitmapCacheOption.OnLoad;
                    image.UriSource = null;
                    image.StreamSource = mem;
                    image.EndInit();
                }
                image.Freeze();

                //Панелька напитка
                StackPanel spMicro = new StackPanel { Orientation = Orientation.Vertical };

                //код напитка
                Label lb = new Label
                {
                    Content = drink.DrinksId,
                    Visibility = Visibility.Hidden,
                    Width = 0,
                    Height = 0
                };

                //добавление картинки
                spMicro.Children.Add(new Image { Source = image });

                // название и цена
                spMicro.Children.Add(new TextBlock
                {
                    Text = $"{drink.Name}\n{drink.Cost}р.",
                    HorizontalAlignment = HorizontalAlignment.Center,
                    TextAlignment = TextAlignment.Center
                });

                //Рамка и вставление туда панельки напитка
                Border border = new Border
                {
                    BorderBrush = Brushes.LightCoral,
                    BorderThickness = new Thickness(2),
                    Child = spMicro,
                    Margin = new Thickness(5),
                    Width = 125,
                    Background = Brushes.PapayaWhip,
                    CornerRadius = new CornerRadius(10)
                };

                //добавление метода выделения напитка
                border.MouseLeftButtonDown += new MouseButtonEventHandler(selectDrinks_Click);

                //добавление элементов
                spDrinks.Children.Add(border);
                spMicro.Children.Add(lb);
            }
            if (cim.Where(c => c.CoinsId == 1).First().IsActive == 0)
            {
                btn10.IsEnabled = false;
            }
            else btn10.IsEnabled = true;
            if (cim.Where(c => c.CoinsId == 2).First().IsActive == 0)
            {
                btn5.IsEnabled = false;
            }
            else btn5.IsEnabled = true;
            if (cim.Where(c => c.CoinsId == 3).First().IsActive == 0)
            {
                btn2.IsEnabled = false;
            }
            else btn2.IsEnabled = true;
            if (cim.Where(c => c.CoinsId == 4).First().IsActive == 0)
            {
                btn1.IsEnabled = false;
            }
            else btn1.IsEnabled = true;
            Update();
        }

        bool selectDrinks = false;

        //Метод выбора нипитка
        private void selectDrinks_Click(object sender, MouseButtonEventArgs e)
        {
            //если не выбрано 
            if ((sender as Border).BorderBrush == Brushes.Green && !selectDrinks)
            {
                //код напитка из скрытой метки
                int b = int.Parse((((sender as Border).Child as StackPanel).Children[2] as Label).Content.ToString());

                //название напитка
                string a = ConnectHelper.entObj.Drinks.Where(d => d.Id == b).First().Name;

                (sender as Border).BorderBrush = Brushes.Blue;
                (sender as Border).Background = Brushes.LightSteelBlue;
                selectDrinks = true;

                //Если выбрано "да"
                if (MessageBox.Show($"Вы выбрали {a}. Купить?", "Покупка", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    //Вычитание цены из общей внесенной суммы
                    Cash.Text = $"{Math.Round(int.Parse(Cash.Text.Split(' ')[0]) - ConnectHelper.entObj.Drinks.Where(d => d.Id == b).First().Cost, 0)} руб.";
                    VendMachineDrinks vmd = ConnectHelper.entObj.VendMachineDrinks.Where(c => c.DrinksId == b && c.VendMachId == 1).First();
                    vmd.Count--;
                    ConnectHelper.entObj.SaveChanges();
                    
                    Update();
                    selectDrinks = false;
                }
                //если "нет" тогда делаем обводку зелёной и снимаем выделение
                else
                {
                    (sender as Border).BorderBrush = Brushes.Green;
                    (sender as Border).Background = Brushes.LimeGreen;
                    selectDrinks = false;
                    //   (((sender as Border).Child as StackPanel).Children[0] as Image);
                }
            }
            //Если выбрано то убрать выделение 
            else if ((sender as Border).BorderBrush == Brushes.Blue && selectDrinks)
            {
                (sender as Border).BorderBrush = Brushes.Green;
                (sender as Border).Background = Brushes.LimeGreen;
                selectDrinks = false;
            }

        }

        // регулирование цвета в зависимости от наличия и от внесенных денег 
        private void Update()
        {

            dim = ConnectHelper.entObj.DrinksInMach.Where(d => d.VendMachId == 1).ToList();
            cim = ConnectHelper.entObj.CoinsInMach.Where(c => c.VendMachId == 1).ToList();
            foreach (UIElement border in spDrinks.Children)
            {
                if (border is Border)
                {
                    //Код напитка из невидимой метки
                    int b = int.Parse((((border as Border).Child as StackPanel).Children[2] as Label).Content.ToString());

                    //Цена напитка
                    decimal a = ConnectHelper.entObj.Drinks.Where(d => d.Id == b).First().Cost;

                    //Текущая внесенная сумма
                    int sum = int.Parse(Cash.Text.Split(' ')[0]);
                    if (ConnectHelper.entObj.DrinksInMach.Where(d => d.Count < 1).Count() > 0)
                        foreach (DrinksInMach dm in ConnectHelper.entObj.DrinksInMach.Where(d => d.Count < 1))
                        {
                            if (dm.DrinksId == b)
                            {
                                (border as Border).BorderBrush = Brushes.DimGray;
                                (border as Border).Background = Brushes.Gray; ;
                            }
                        }
                    //Если можно купить
                    if (sum >= a)
                    {
                        if (ConnectHelper.entObj.DrinksInMach.Where(d => d.Count < 1 && d.DrinksId == b).Count() > 0) continue;
                        (border as Border).BorderBrush = Brushes.Green;
                        (border as Border).Background = Brushes.LimeGreen;
                    }
                    else
                    {
                        if (ConnectHelper.entObj.DrinksInMach.Where(d => d.Count < 1 && d.DrinksId == b).Count() > 0) continue;
                        (border as Border).BorderBrush = Brushes.LightCoral;
                        (border as Border).Background = Brushes.PapayaWhip;
                    }
                }
            }

        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            int sum = int.Parse(Cash.Text.Split(' ')[0]);
            Cash.Text = $"{sum + 1} руб.";
            coins[3] += 1;
            Update();
        }

        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            int sum = int.Parse(Cash.Text.Split(' ')[0]);
            Cash.Text = $"{sum + 2} руб.";
            coins[2] += 1;
            Update();
        }

        private void btn5_Click(object sender, RoutedEventArgs e)
        {
            int sum = int.Parse(Cash.Text.Split(' ')[0]);
            Cash.Text = $"{sum + 5} руб.";
            coins[1] += 1;
            Update();
        }

        private void btn10_Click(object sender, RoutedEventArgs e)
        {
            int sum = int.Parse(Cash.Text.Split(' ')[0]);
            Cash.Text = $"{sum + 10} руб.";
            coins[0] += 1;
            Update();
        }

        private void btnChange_Click(object sender, RoutedEventArgs e)
        {
            int change = int.Parse(Cash.Text.Split(' ')[0]);
            int b = change;
            int[] coinsChange = { 0, 0, 0, 0 };
            while (b != 0)
            {
                if (coins[0] > 0 && b - 10 >= 0)
                {
                    b -= 10;
                    coins[0]--;
                    coinsChange[0]++;
                }
                else if (coins[1] > 0 && b - 5 >= 0)
                {
                    b -= 5;
                    coins[1]--;
                    coinsChange[1]++;
                }
                else if (coins[2] > 0 && b - 2 >= 0)
                {
                    b -= 2;
                    coins[2]--;
                    coinsChange[2]++;
                }
                else if (coins[3] > 0 && b - 1 >= 0)
                {
                    b -= 1;
                    coins[3]--;
                    coinsChange[3]++;
                }
                else
                {
                    break;
                }
            }
            while (b != 0)
            {
                if (b - 10 >= 0 && cim.Where(c => c.Count > 0 && c.CoinsId == 1).Count() > 0)
                {
                    b -= 10;
                    coinsChange[0]++;
                    VendMachineCoins vmc = ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 1 && c.VendMachId == 1).First();
                    vmc.Count--;
                }
                else if (b - 5 >= 0 && cim.Where(c => c.Count > 0 && c.CoinsId == 2).Count() > 0)
                {
                    b -= 5;
                    coinsChange[1]++;
                    VendMachineCoins vmc = ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 1 && c.VendMachId == 1).First();
                    vmc.Count--;
                }
                else if (b - 2 >= 0 && cim.Where(c => c.Count > 0 && c.CoinsId == 3).Count() > 0)
                {
                    b -= 2;
                    coinsChange[2]++;
                    VendMachineCoins vmc = ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 1 && c.VendMachId == 1).First();
                    vmc.Count--;
                }
                else if (b - 1 >= 0 && cim.Where(c => c.Count > 0 && c.CoinsId == 4).Count() > 0)
                {
                    b -= 1;
                    coinsChange[3]++;
                    VendMachineCoins vmc = ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 1 && c.VendMachId == 1).First();
                    vmc.Count--;
                }
            }
            string check = "";
            if (coinsChange[0] != 0)
                check += $"{coinsChange[0]} х 10 руб.";
            if (coinsChange[1] != 0)
                check += $"{coinsChange[1]} х 5 руб.";
            if (coinsChange[2] != 0)
                check += $"{coinsChange[2]} х 2 руб.";
            if (coinsChange[3] != 0)
                check += $"{coinsChange[3]} х 1 руб.";
            MessageBox.Show($"Выдано { check}. В итоге {coinsChange[0] * 10 + coinsChange[1] * 5 + coinsChange[2] * 2 + coinsChange[3] * 1} руб.");
            Cash.Text = "0 руб.";
            ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 1 && c.VendMachId == 1).First().Count += coins[0];
            ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 2 && c.VendMachId == 1).First().Count += coins[1];
            ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 3 && c.VendMachId == 1).First().Count += coins[2];
            ConnectHelper.entObj.VendMachineCoins.Where(c => c.CoinsId == 4 && c.VendMachId == 1).First().Count += coins[3];
            coins[0] = 0;
            coins[1] = 0;
            coins[2] = 0;
            coins[3] = 0;
            coinsChange[0] = 0;
            coinsChange[1] = 0;
            coinsChange[2] = 0;
            coinsChange[3] = 0;
            ConnectHelper.entObj.SaveChanges();
            Update();
        }

        private void Page_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyboardDevice.IsKeyDown(Key.LeftShift) && e.KeyboardDevice.IsKeyDown(Key.Enter))
            {
                FrameApp.frmObj.Navigate(new MainAdmin());
                Update();
                //lPass.Visibility = Visibility.Visible;
                //Cash.Text = "";
                //Cash.IsReadOnly = false;
                //Cash.Focus();
            }

            //if (lPass.Visibility == Visibility.Visible)
            //{
            //    Cash.Text += e.Key.ToString().Last();

            //    if(ConnectHelper.entObj.VendingMachine.Where(x => x.SecretCode == Cash.Text) != null) FrameApp.frmObj.Navigate(new MainAdmin());

            //    if (Cash.Text.Length == 4) 
            //    { 
            //        Cash.Text = "";
            //        Cash.IsReadOnly = true;
            //        lPass.Visibility = Visibility.Hidden;
            //        Update();
            //    }
            //}
        }

        private void Cash_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
